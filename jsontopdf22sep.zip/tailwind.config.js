/** @type {import('tailwindcss').Config} */
module.exports = {
  content: ["./src/**/*.{html,js}", "./index.js"],
  theme: {
    extend: {},
  },
  plugins: [],
};
