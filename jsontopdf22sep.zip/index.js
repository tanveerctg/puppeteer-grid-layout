const puppeteer = require("puppeteer");
const fs = require("fs");

const express = require("express");
const app = express();

app.get("/", async function (req, res) {
  // Create a browser instance
  const browser = await puppeteer.launch();

  // Create a new page
  const page = await browser.newPage();

  //read data from html template
  //Get HTML content from HTML file
  const html = fs.readFileSync("./src/sample.html", "utf-8");
  const css = fs.readFileSync("./dist/output.css", "utf-8");

  function generateSec(obj, section = "") {
    if (!obj.children)
      return section.concat(
        `<${obj.container} class='text-red-300 text-center uppercase leading-loose decoration-slate-200 text-3xl'>${obj.content}</${obj.container}>`
      );
    const allChild = obj.children
      .map((child) => {
        return generateSec(child, section);
      })
      .join("");
    startTag = `<${obj.container} class='flex'>`;
    endTag = `</${obj.container}>`;
    return startTag + allChild + endTag;
  }

  const htmlData = generateSec(
    {
      container: "section",
      grid: 2,
      children: [
        {
          container: "section",
          grid: 2,
          children: [
            {
              container: "div",
              children: [
                {
                  container: "div",
                  content: "child 1-1",
                },
                {
                  container: "div",
                  content: "child 1-2",
                },
              ],
            },
            {
              container: "div",
              content: "child 2",
            },
          ],
        },
        {
          container: "section",
          grid: 2,
          children: [
            {
              container: "div",
              children: [
                {
                  container: "div",
                  content: "child 2-1",
                },
                {
                  container: "div",
                  content: "child 2-2",
                },
              ],
            },
            {
              container: "div",
              content: "child 2",
            },
          ],
        },
        {
          container: "section",
          grid: 2,
          children: [
            {
              container: "div",
              children: [
                {
                  container: "div",
                  content: "child 3-1",
                },
                {
                  container: "div",
                  content: "child 3-2",
                },
              ],
            },
            {
              container: "div",
              content: "child 2",
            },
          ],
        },
      ],
    },
    ""
  );

  function generateHtml(obj, section = "") {
    if (!obj.components) {
      if (obj.type === "table") {
        return `<div class="${obj.options.class}">
            <table class="w-full text-sm text-left" >
              <thead class="text-sm text-[${
                obj.options.stripedTable.color1
              }] bg-[${obj.options.stripedTable.stripedColor1}]">
                <tr>
                    ${obj.options.tHeads
                      .map(
                        (tHead, index) =>
                          `<th class="px-6 py-2">                       
                          ${tHead}    
                           </th>`
                      )
                      .join("")}
                </tr>
              </thead>
              <tbody>
                ${obj.options.tRows
                  .map(
                    (tRow, tRowIndex) =>
                      `<tr                  
                        class=
                        "${
                          tRowIndex % 2 === 0
                            ? `text-sm text-[${obj.options.stripedTable.color2}] bg-[${obj.options.stripedTable.stripedColor2}]`
                            : `text-sm text-[${obj.options.stripedTable.color1}] bg-[${obj.options.stripedTable.stripedColor1}]`
                        }"
                    >${Object.values(tRow)
                      .map((val) => `<td class="px-6 py-2">${val}</td>`)
                      .join("")}
                      </tr>`
                  )
                  .join("")}
              </tbody>
            </table>
          </div>`;
      }

      if (obj.type === "card-1") {
        return `<div class="${obj.options.class} card">
            <p class="text-[#067c7c] font-semibold uppercase">
             ${obj.options.title}
            </p>
            <div class="flex items-center space-x-4 mt-2">
              <h3 class="text-base font-semibold">${obj.options.icon}</h3>
              <h3 class="text-3xl">${obj.options.number} ${obj.options.unit}</h3>
            </div>
          </div>`;
      }

      return section.concat(
        `<div class="${obj.options.class}">${obj.options.value || ""}</div>`
      );
    }
    const allChild = obj.components
      .map((child) => {
        return generateHtml(child, section);
      })
      .join("");
    startTag = `<div class="${obj.options.class} ${obj.type} py-2">`;
    endTag = `</div>`;
    return startTag + allChild + endTag;
  }

  const jsonToHtml = (arrayOfSection) => {
    let html = "";
    arrayOfSection.forEach((section) => {
      html += generateHtml(section, "");
    });

    return `<div class="container mx-auto">${html}</div>`;
  };

  const json = [
    {
      id: 1,
      type: "section",
      options: {
        class: "p-4 border-b-4 border-red-500",
      },
      components: [
        {
          id: "1__1",
          type: "row",
          options: {
            class: "grid grid-cols-12 gap-4",
          },
          components: [
            {
              id: "1__1__1",
              type: "header",
              options: {
                class: "col-span-6",
              },
              components: [
                {
                  id: "1__1__1__1",
                  type: "text",
                  options: {
                    class: "text-2xl font-semibold",
                    value: "Example.com",
                  },
                },
                {
                  id: "1__1__1__2",
                  type: "text",
                  options: {
                    class: "",
                    value: "Monthly analytics report",
                  },
                },
              ],
            },
            {
              id: "1__1__2",
              type: "block",
              options: {
                class: "col-span-6 text-right",
              },
              components: [
                {
                  id: "1__1__2__1",
                  type: "text",
                  options: {
                    class: "",
                    value: "Made with hibiscus",
                  },
                },
                {
                  id: "1__1__2__2",
                  type: "text",
                  options: {
                    class: "",
                    value: "v0.1.0",
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      id: 2,
      type: "section",
      options: {
        class: "bg-[#f8f5f2] p-4",
      },
      components: [
        {
          id: "2__3",
          type: "text",
          options: {
            class: "text-2xl font-semibold pb-2",
            value: "Overviews and KPI metrics",
          },
        },
        {
          id: "2__2",
          type: "seperator",
          options: {
            class: "h-[2px] bg-red-500 mb-3",
          },
        },
        {
          id: "2__3",
          type: "row",
          options: {
            class: "grid gap-4 grid-cols-12",
          },
          components: [
            {
              id: "2__3__1",
              type: "card-1",
              options: {
                class: "bg-white col-span-4 p-3 rounded-md",
                title: "Unique views",
                icon: "icon src",
                number: 987,
                unit: "views",
              },
            },
            {
              id: "2__3__2",
              type: "card-1",
              options: {
                class: "bg-white col-span-4 p-3 rounded-md",
                title: "Unique views",
                icon: "icon src",
                number: 987,
                unit: "views",
              },
            },
            {
              id: "2__3__3",
              type: "card-1",
              options: {
                class: "bg-white col-span-4 p-3 rounded-md",
                title: "Unique views",
                icon: "icon src",
                number: 987,
                unit: "views",
              },
            },
            {
              id: "2__3__4",
              type: "card-1",
              options: {
                class: "bg-white col-span-4 p-3 rounded-md",
                title: "Unique views",
                icon: "icon src",
                number: 987,
                unit: "views",
              },
            },
          ],
        },
      ],
    },
    {
      id: 4,
      type: "section",
      options: {
        class: "p-4",
      },
      components: [
        {
          id: "4__1",
          type: "text",
          options: {
            class: "text-2xl font-semibold border-b-2 border-red-500 pb-2 mb-3",
            value: "Key performing pages",
          },
        },
        {
          id: "4__2",
          type: "table",
          options: {
            class: "overflow-x-auto relative shadow-sm sm:rounded-lg",
            moduleName: "Deals",
            highlited: false,
            stripedTable: {
              value: true,
              stripedColor1: "#f8f5f2",
              stripedColor2: "#880808",
              color1: "#333",
              color2: "#333",
            },
            fields: ["product_name", "color", "category"],
            tHeads: ["Product name", "Color", "Category"],
            tRows: [
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
            ],
          },
        },
      ],
    },
    {
      id: 3,
      type: "section",
      options: {
        class: "p-4 bg-[#f8f5f2]",
      },
      components: [
        {
          id: "3__1",
          type: "text",
          options: {
            class: "text-2xl font-semibold border-b-2 border-red-500 pb-2 mb-3",
            value: "Overviews and KPI metrics",
          },
        },
        {
          id: "3__2",
          type: "row",
          options: {
            class: "grid gap-4 grid-cols-12",
          },
          components: [
            {
              id: "3__2__1",
              type: "text",
              options: {
                class: "col-span-4",
                value:
                  "Lorem ipsum dolor sit amet consectetur, adipisicing elit. Doloribus animi fuga nulla",
              },
            },
            {
              id: "3__2__2",
              type: "row",
              options: {
                class: "col-span-8 grid gap-4 grid-cols-2 parent",
              },
              components: [
                {
                  id: "3__2__2__1",
                  type: "card-1",
                  options: {
                    class: "bg-white p-3 rounded-md wrapper",
                    title: "Unique views",
                    icon: "icon src",
                    number: 987,
                    unit: "views",
                  },
                },
                {
                  id: "3__2__2__2",
                  type: "card-1",
                  options: {
                    class: "bg-white p-3 rounded-md wrapper",
                    title: "Unique views",
                    icon: "icon src",
                    number: 987,
                    unit: "views",
                  },
                },
                {
                  id: "3__2__2__3",
                  type: "card-1",
                  options: {
                    class: "bg-white p-3 rounded-md wrapper",
                    title: "Unique views",
                    icon: "icon src",
                    number: 987,
                    unit: "views",
                  },
                },
                {
                  id: "3__2__2__4",
                  type: "card-1",
                  options: {
                    class: "bg-white p-3 rounded-md wrapper",
                    title: "Unique views",
                    icon: "icon src",
                    number: 987,
                    unit: "views",
                  },
                },
              ],
            },
          ],
        },
      ],
    },
    {
      id: 5,
      type: "section",
      options: {
        class: "p-4",
      },
      components: [
        {
          id: "5__1",
          type: "text",
          options: {
            class: "text-2xl font-semibold border-b-2 border-red-500 pb-2 mb-3",
            value: "Key performing pages",
          },
        },
        {
          id: "5__2",
          type: "table",
          options: {
            class: "overflow-x-auto relative shadow-sm sm:rounded-lg",
            moduleName: "Deals",
            stripedTable: {
              value: true,
              stripedColor1: "#f8f5f2",
              stripedColor2: "#fff",
              color1: "#333",
              color2: "#333",
            },

            tHeads: ["Product name", "Color", "Category"],
            tRows: [
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Microsoft Surface Pro",
                color: "White",
                category: "Laptop PC",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
              {
                p_name: "Apple MacBook Pro 17",
                color: "Sliver",
                category: "Laptop",
              },
            ],
          },
        },
      ],
    },
  ];

  const compileTailwind = `<!DOCTYPE html>
 <html lang="en" style="padding-top:15px;padding-bottom:15px;">
   <head>
     <meta charset="UTF-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <meta name="viewport" content="width=device-width, initial-scale=1.0" />
     <title>Document</title>
     <link rel="preconnect" href="https://fonts.googleapis.com">
     <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
     <link href="https://fonts.googleapis.com/css2?family=Combo&family=Ms+Madi&family=Oswald:wght@700&display=swap" rel="stylesheet">
     <style>
        ${css}
        thead {
          display: table-header-group;
          break-inside: avoid;
        }
        .parent {
          display: block;
        }
        
        .wrapper {
          display: block;
          float: left;
          break-inside: avoid;
        }
     </style>
   </head>
   <body>
    ${jsonToHtml(json)}
   </body>
  </html>`;

  await page.setContent(compileTailwind, { waitUntil: "networkidle0" });

  //To reflect CSS used for screens instead of print
  await page.emulateMediaType("screen");

  // Get the "viewport" of the page, as reported by the page.
  const dimensions = await page.evaluate(() => {
    console.log(document.querySelector(".card").innerHTML);
    console.log(document.querySelectorAll(".section")[3].offsetHeight);
    return {
      width: document.documentElement.clientWidth,
      height: document.documentElement.clientHeight,
      deviceScaleFactor: window.devicePixelRatio,
      top: document.querySelectorAll(".section")[3].getBoundingClientRect().top,
      sectionHeight: document.querySelectorAll(".section")[3].clientHeight,
    };
  });

  console.log("Dimensions:", dimensions);
  // Downlaod the PDF
  const pdf = await page.pdf({
    path: "./result.pdf",
    margin: { bottom: "50px", top: "50px", left: "25px", right: "25px" },
    printBackground: true,
    format: "A4",
    displayHeaderFooter: true,
    //   headerTemplate: `<html>
    //   <style>
    //   *{
    //     font-size: 11px !important;
    //     width:100%;
    //     margin: 0 12px !important;
    //     color:black;
    //   }
    //   #header-template img{
    //     padding:0;
    //     margin:0;
    //   }
    //   #header-template .random>*{
    //       margin:0;
    //       padding:3px 0;
    //   }
    //   .singleElement{
    //       padding:0;
    //       margin:0;
    //   }
    //   </style>
    //   <body><h1>Hello From Header</h1></body>
    // </html>`,
    //   footerTemplate: `<html>
    //   <style>
    //   *{
    //     font-size: 16px !important;
    //     width:100%;
    //     margin: 0 16px !important;
    //     color:black;
    //   }
    //   #header-template img{
    //     padding:0;
    //     margin:0;
    //   }
    //   #header-template .random>*{
    //       margin:0;
    //       padding:3px 0;
    //   }
    //   .singleElement{
    //       padding:0;
    //       margin:0;
    //   }
    //   </style>
    //   <body><h1>Hello From Footer</h1></body>
    // </html>`,
  });

  // Close the browser instance
  await browser.close();
  res.contentType("application/pdf");
  res.send(pdf);
});

app.listen(9000);
